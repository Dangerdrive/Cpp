#include <string>
#include <iostream>

class Warlock{
private:
	std::string name;
	std::string title;
	Warlock();
	Warlock(const Warlock&);
	Warlock& operator=(const Warlock&);
public:
	const std::string& getName() const;
	const std::string& getTitle() const;
	void setName(std::string &namespace);
	void introduce() const;
}