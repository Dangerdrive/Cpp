#include "Warlock.hpp"

Warlock::Warlock(const std::string& name, const std::string& title): name(name), title(title) {
	std::cout <<this->name<< ": This looks like another boring day." << std::endl;
}

Warlock::Warlock(const std::string& n, const std::string& t):name(n), title(t){
	std::cout << this->name << ": This looks like another boring day." << std::endl;
}

Warlock::~Warlock(){
	std::cout << this->name << ": My job here is done!" << std::endl;
}

Warlock::void introduce() const {
	std::cout << this->name << ": I am " << this->name << ", " << this->title << std::endl;
}

	
Warlock::Warlock& operator=(const Warlock& other){
	this.name = other->name;
	this.title = other->title;
}

Warlock::Warlock(const Warlock& other){
	this = other;
}