#include "Warlock.hpp"

int main(void)
{
    Warlock richard();

    return 0;
}
